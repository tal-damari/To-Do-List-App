package com.example.todolistapp;

public class CheckBoxName {
    String name;
    public CheckBoxName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
}
